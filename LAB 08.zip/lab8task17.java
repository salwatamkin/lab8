import java.util.Scanner;
public class lab8task17{
    public static void main(String[]args){
        Scanner sc= new Scanner(System.in);
        System.out.println("enter line quantity");
        int l= sc.nextInt();
        for(int line=1;line<=l;line++){
            for(int column=1;column<=line;column++){
                if(line==1||line==l){
                    System.out.print(column);
                }
                else if(column==1||column==line){
                    System.out.print(column);
                }
                else {
                    System.out.print(" ");
                }
            }
            System.out.println();
        }
    }
}