import java.util.Scanner;
public class lab8task2{
    public static void main(String[]args){
        Scanner sc= new Scanner(System.in);
        System.out.println("enter column quantity");
        int c=sc.nextInt();
        for(int column=1;column<=c;column++){
            System.out.print("*");
        }
    }
}