import java.util.Scanner;
public class lab8task15{
    public static void main(String[]args){
        Scanner sc= new Scanner(System.in);
        System.out.println("enter length quantity");
        int l= sc.nextInt();
        System.out.println("enter width quantity");
        int c= sc.nextInt();
        for(int line=1;line<=l;line++){
            for(int column=1;column<=c;column++){
                if(line==1||line==l||column==1||column==c){
                    System.out.print(column);
                }
                else {
                    System.out.print(" ");
                }
            }
            System.out.println();
        }
    }
}
