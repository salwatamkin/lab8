import java.util.Scanner;
public class lab8task25{
    public static void main(String[]args){
        Scanner sc= new Scanner(System.in);
        System.out.println("enter line quantity");
        int l=sc.nextInt();
        for(int line=1;line<=l;line++){
            for(int space=1;space<=l-line;space++){
                System.out.print(" ");
            }
            for(int column1=1;column1<=line;column1++){
                System.out.print(column1);
            }
            for(int column2=line-1;column2>=1;column2--){
                System.out.print(column2);
            }
            System.out.println();
        }
    }
}