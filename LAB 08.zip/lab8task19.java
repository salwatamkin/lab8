import java.util.Scanner;
public class lab8task19{
    public static void main(String[]args){
        Scanner sc= new Scanner(System.in);
        System.out.println("enter line quantity");
        int l= sc.nextInt();
        for(int line=1;line<=l;line++){
            int space;
            for(space=1;space<=l-line;space++){
                System.out.print(" ");
            }
            for(int column=space;column<=l;column++){
                if(line==1||line==l){
                    System.out.print(column);
                }
                else if(column==l||column==space){
                    System.out.print(column);
                }
                else {
                    System.out.print(" ");
                }
            }
            System.out.println();
        }
    }
}