import java.util.Scanner;
public class lab8task24{
    public static void main(String[]args){
        Scanner sc= new Scanner(System.in);
        System.out.println("enter a number");
        int n=sc.nextInt();
        for(int column1=1;column1<=n;column1++){
            System.out.print(column1);
        }
        for(int column2=n-1;column2>=1;column2--){
            System.out.print(column2);
        }
    }
}
