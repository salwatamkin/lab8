import java.util.Scanner;
public class lab8task11{
    public static void main(String[]args){
        Scanner sc= new Scanner(System.in);
        System.out.println("enter line quantity");
        int l= sc.nextInt();
        for(int line=1;line<=l;line++){
            int space;
            for(space=1;space<=l-line;space++){
                System.out.print(" ");
            }
            for(int column=space;column<=l;column++){
                System.out.print(column);
            }
            System.out.println();
        }
    }
}

            