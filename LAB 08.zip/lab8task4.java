import java.util.Scanner;
public class lab8task4{
    public static void main(String[]args){
        Scanner sc= new Scanner(System.in);
        System.out.println("enter line quantity");
        int l=sc.nextInt();
        System.out.println("enter column quantity");
        int c=sc.nextInt();
        for(int line=1;line<=l;line++){
            for(int column=1;column<=c;column++){
            System.out.print(column);
            }
            System.out.println();
        }
    }
}