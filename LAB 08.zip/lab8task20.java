import java.util.Scanner;
public class lab8task20{
    public static void main(String[]args){
        Scanner sc= new Scanner(System.in);
        System.out.println("enter line quantity");
        int l= sc.nextInt();
        int starcount=1;
        for(int line=1;line<=l;line++){
            for(int space=1;space<=l-line;space++){
                System.out.print(" ");
            }
            for(int column=1;column<=starcount;column++){
                if(line==1||line==l||column==1||column==starcount){
                    System.out.print("*");
                }
                else {
                    System.out.print(" ");
                }
            }
            System.out.println();
            starcount+=2;
        }
    }
}